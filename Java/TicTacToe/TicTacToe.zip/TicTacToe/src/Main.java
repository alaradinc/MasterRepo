import java.util.Random;

public class Main {
    public static void main(String[] args) {
//        XoxoGame game = new XoxoGame();
//        game.start();
//

//        System.out.printf("%10s %10d %10s %d\n","Alara",15,"Murat",20);
//        System.out.printf("%10s %10d %10s %d\n","Ayberk",15,"Murat",20);
//        System.out.printf("%10s %10d %10s %d\n","Ali",15,"Murat",20);




//        Random rand = new Random();
//
//
//        for(int i = 1; i<6; i++){
//            int sum = 0;
//            for(int j = 0; j<(int)Math.pow(10,i); j++){
//                sum += rand.nextInt((int)Math.pow(10,i));
//            }
//            System.out.println((float)sum/(int)Math.pow(10,i));
//        }
    }
}
